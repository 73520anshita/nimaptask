package com.nimaptask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NiMapTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(NiMapTaskApplication.class, args);
	}

}
